export default function Notificaciones() {
  return (
    <h1>Aquí están tus notificaciones</h1>
  )
}
