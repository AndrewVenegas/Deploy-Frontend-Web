// const API_URL = 'http://localhost:3000';
const API_URL = 'https://api-turnosuc.onrender.com'

export default API_URL;